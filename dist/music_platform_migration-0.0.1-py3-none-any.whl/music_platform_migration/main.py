def hello_world():
    print("HelloWorld")
