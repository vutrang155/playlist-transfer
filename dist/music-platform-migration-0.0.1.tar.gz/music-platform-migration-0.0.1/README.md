A script to migrates your playlists between platforms
